const Blog = require('../models/blogModel');

// GET all blogs (newest first)
const getAllBlogs = async (req, res) => {
  try {
    const blogs = await Blog.find().sort({ createdAt: -1 });
    res.status(200).json(blogs);
  } catch (error) {
    console.error('getAllBlogs error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// CREATE a new blog (accepts optional image)
const createBlog = async (req, res) => {
  const { title, content, image } = req.body || {};
  if (!title || !content) {
    return res.status(400).json({ message: 'Title and content required' });
  }

  try {
    const newBlog = new Blog({
      title,
      content,
      image: image || 'https://via.placeholder.com/800x500?text=Blog'
    });
    const savedBlog = await newBlog.save();
    res.status(201).json(savedBlog);
  } catch (error) {
    console.error('createBlog error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = { getAllBlogs, createBlog };