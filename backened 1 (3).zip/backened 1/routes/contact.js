const express = require('express');
const router = express.Router();
const Contact = require('../models/Contact');

router.post('/contact', async (req, res) => {
  try {
    const { name, email, message } = req.body || {};
    if (!name || !email || !message) {
      return res.status(400).json({ success: false, message: 'All fields are required' });
    }
    await Contact.create({ name, email, message });
    return res.json({ success: true, message: 'Message saved successfully!' });
  } catch (err) {
    console.error('Contact route error:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;