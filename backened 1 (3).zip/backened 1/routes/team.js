const express = require('express');
const router = express.Router();
const TeamMember = require('../models/TeamMember');

router.get('/team', async (req, res) => {
  const members = await TeamMember.find();
  res.json(members);
});

module.exports = router;
