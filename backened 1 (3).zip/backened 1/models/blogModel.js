const mongoose = require('mongoose');

const blogSchema = new mongoose.Schema({
  title:   { type: String, required: true },
  content: { type: String, required: true },
  image:   { type: String, default: '' },  // added so frontend thumbnails work
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.models.Blog || mongoose.model('Blog', blogSchema);