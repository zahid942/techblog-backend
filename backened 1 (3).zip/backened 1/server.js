const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const dotenv = require("dotenv");

dotenv.config();

const app = express();

/* ===== CORS (Netlify mains + previews) ===== */
const allowlist = new Set([
  "https://68ab447dd78d300b4d91ef8c--melodic-longma-a14a04.netlify.app",
  "https://68ac0f7a9190c8270d038fdb--loquacious-mandazi-d203d6.netlify.app",
  "https://friendly-sundae-24a848.netlify.app",
  "https://spectacular-dodol-f51be1.netlify.app"
]);

const previewRegexes = [
  /^[a-z0-9-]+--melodic-longma-a14a04\.netlify\.app$/i,
  /^[a-z0-9-]+--loquacious-mandazi-d203d6\.netlify\.app$/i,
  /^[a-z0-9-]+--friendly-sundae-24a848\.netlify\.app$/i,
  /^[a-z0-9-]+--spectacular-dodol-f51be1\.netlify\.app$/i
];

const corsOptions = {
  origin: (origin, callback) => {
    if (!origin) return callback(null, true);
    try {
      const host = new URL(origin).host;
      if (allowlist.has(origin) || previewRegexes.some(rx => rx.test(host))) {
        return callback(null, true);
      }
    } catch {}
    return callback(new Error("Not allowed by CORS"), false);
  },
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  credentials: true
};

app.use(cors(corsOptions));
app.options("*", cors(corsOptions));
app.use(express.json());

/* ===== Cached MongoDB connection for serverless ===== */
const MONGO_URI = process.env.MONGO_URI;
let cached = global._mongoose;
if (!cached) cached = global._mongoose = { conn: null, promise: null };

async function dbConnect() {
  if (cached.conn) return cached.conn;
  if (!cached.promise) {
    cached.promise = mongoose.connect(MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      serverSelectionTimeoutMS: 30000,
      family: 4,
      keepAlive: true,
      keepAliveInitialDelay: 300000
    }).then(m => m);
  }
  cached.conn = await cached.promise;
  return cached.conn;
}

/* ===== Models ===== */
const UserSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  password: String
});
const User = mongoose.models.User || mongoose.model("User", UserSchema);

const BlogSchema = new mongoose.Schema({
  title: String,
  content: String,
  image: String,
  createdAt: { type: Date, default: Date.now }
});
const Blog = mongoose.models.Blog || mongoose.model("Blog", BlogSchema);

const ContactSchema = new mongoose.Schema({
  name: String,
  email: String,
  message: String,
  createdAt: { type: Date, default: Date.now }
});
const Contact = mongoose.models.Contact || mongoose.model("Contact", ContactSchema);

/* ===== Probes ===== */
app.get("/api/health", (req, res) => res.json({ ok: true }));
app.get("/api/db-status", async (req, res) => {
  // Try to connect, then report state
  try { await dbConnect(); } catch (_) {}
  res.json({
    uriSet: Boolean(process.env.MONGO_URI),
    state: mongoose.connection.readyState // 0=down,1=connected,2=connecting,3=disconnecting
  });
});

/* ===== Auth ===== */
app.post("/api/register", async (req, res) => {
  await dbConnect();
  try {
    const { name, email, password } = req.body || {};
    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ message: "User already exists" });

    const hashedPassword = await bcrypt.hash(password, 10);
    await new User({ name, email, password: hashedPassword }).save();
    res.status(201).json({ message: "User created successfully" });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

app.post("/api/login", async (req, res) => {
  await dbConnect();
  try {
    const { email, password } = req.body || {};
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ message: "User not found" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ message: "Invalid credentials" });

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET || "secretkey", { expiresIn: "1h" });
    res.json({ message: "Login successful", token });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

/* ===== Blogs ===== */
app.get("/api/posts", async (req, res) => {
  await dbConnect();
  try {
    const posts = await Blog.find().sort({ createdAt: -1 });
    res.json(posts);
  } catch (err) {
    res.status(500).json({ message: "Error fetching posts" });
  }
});

app.post("/api/posts", async (req, res) => {
  await dbConnect();
  try {
    const { title, content, image } = req.body || {};
    const saved = await new Blog({ title, content, image }).save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(500).json({ message: "Error creating post" });
  }
});

/* ===== Contact ===== */
app.post("/api/contact", async (req, res) => {
  await dbConnect();
  try {
    const { name, email, message } = req.body || {};
    if (!name || !email || !message) {
      return res.status(400).json({ success: false, message: "All fields are required" });
    }
    await Contact.create({ name, email, message });
    return res.json({ success: true, message: "Message saved successfully!" });
  } catch (err) {
    console.error("Contact route error:", err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
});

/* ===== Misc ===== */
app.get("/favicon.ico", (req, res) => res.status(204).end());
app.get("/", (req, res) => res.send("Backend is running ✅"));

/* ===== Server ===== */
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));